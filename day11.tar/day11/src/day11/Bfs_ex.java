package day11;

public class Bfs_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/*
		 * \\
		 * 4 5 1
		   1 2
		   1 3
  		   1 4
		   2 4
		   3 4
		 */
	}

}
